


import { createSlice } from '@reduxjs/toolkit';
// import type { PayloadAction } from '@reduxjs/toolkit';
// import {RootState} from "@/lib/store";
import {RootState} from '../../app/store';
interface productsState {
    value: number
}


const initialState: productsState = {
    value: 0,
};

export const productSlice = createSlice({
    name: 'products',

    initialState,
    reducers: {

    },
});

export const {

} = productSlice.actions;


export const selectCount = (state: RootState) => state.products.value;

export default productSlice.reducer;
